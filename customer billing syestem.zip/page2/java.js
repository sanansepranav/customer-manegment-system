let total = 0;

// Load saved bill on page load
window.onload = function () {
  const savedBill = JSON.parse(localStorage.getItem("fabricBill"));
  if (savedBill) {
    document.getElementById("customerName").value = savedBill.customerName;
    document.getElementById("customerMobile").value = savedBill.customerMobile;
    document.getElementById("billDate").value = savedBill.billDate;
    total = savedBill.total || 0;

    const tableBody = document.querySelector("#billTable tbody");
    tableBody.innerHTML = " "; //inner row

    savedBill.items.forEach(item => {
      const row = tableBody.insertRow();
      row.innerHTML = `
        <td>${item.name}</td>
        <td>${item.qty}</td>
        <td>₹${item.price}</td>
        <td>₹${item.total}</td>
      `;
  });

    document.getElementById("grandTotal").textContent = `Total: ₹${total.toFixed(2)}`;
  }
};

function saveToLocalStorage() {
  const items = [];
  const rows = document.querySelectorAll("#billTable tbody tr");
  rows.forEach(row => {
    const cells = row.querySelectorAll("td");
    items.push({
      name: cells[0].textContent,
      qty: parseInt(cells[1].textContent),
      price: parseFloat(cells[2].textContent.replace("₹", "")),
      total: parseFloat(cells[3].textContent.replace("₹", ""))
    });
  });

  const data = {
    customerName: document.getElementById("customerName").value,
    customerMobile: document.getElementById("customerMobile").value,
    billDate: document.getElementById("billDate").value,
    items: items,
    total: total
  };

  localStorage.setItem("fabricBill", JSON.stringify(data));
}

function addItem() {
  const name = document.getElementById('clothName').value.trim();
  const qty = parseInt(document.getElementById('quantity').value);
  const price = parseFloat(document.getElementById('price').value);

  if (!name || isNaN(qty) || isNaN(price) || qty <= 0 || price <= 0) {
    alert("Please enter valid item details.");
    return;
  }

  const itemTotal = qty * price;
  total += itemTotal;

  const table = document.getElementById('billTable').getElementsByTagName('tbody')[0];
  const row = table.insertRow();
  row.innerHTML = `
    <td>${name}</td>
    <td>${qty}</td>
    <td>₹${price.toFixed(2)}</td>
    <td>₹${itemTotal.toFixed(2)}</td>
  `;

  document.getElementById('grandTotal').textContent = `Total: ₹${total.toFixed(2)}`;

  document.getElementById('clothName').value = '';
  document.getElementById('quantity').value = '';
  document.getElementById('price').value = '';

  saveToLocalStorage();
}

function resetBill() {
  if (confirm("Clear the bill?")) {
    localStorage.removeItem("fabricBill");
    location.reload();
  }
}

